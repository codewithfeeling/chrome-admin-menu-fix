# chrome-admin-menu-fix
August 2015 - Chrome is mangling WordPress menus. This is a quick fix which collapses and uncollapses the menu solving the issue for now.
